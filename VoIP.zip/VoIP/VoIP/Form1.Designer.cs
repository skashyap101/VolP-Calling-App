﻿using System.Windows.Forms;

namespace VoIPCallingApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblIP;
        private TextBox txtIP;
        private Label lblPort;
        private TextBox txtPort;
        private Button btnStartCall;
        private Button btnEndCall;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblIP = new Label();
            this.txtIP = new TextBox();
            this.lblPort = new Label();
            this.txtPort = new TextBox();
            this.btnStartCall = new Button();
            this.btnEndCall = new Button();
            this.SuspendLayout();

            // lblIP
            this.lblIP.AutoSize = true;
            this.lblIP.Location = new System.Drawing.Point(20, 20);
            this.lblIP.Name = "lblIP";
            this.lblIP.Size = new System.Drawing.Size(60, 13);
            this.lblIP.Text = "Remote IP";

            // txtIP
            this.txtIP.Location = new System.Drawing.Point(110, 17);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(150, 20);

            // lblPort
            this.lblPort.AutoSize = true;
            this.lblPort.Location = new System.Drawing.Point(20, 60);
            this.lblPort.Name = "lblPort";
            this.lblPort.Size = new System.Drawing.Size(69, 13);
            this.lblPort.Text = "Remote Port";

            // txtPort
            this.txtPort.Location = new System.Drawing.Point(110, 57);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(150, 20);
            this.txtPort.Text = "6000";

            // btnStartCall
            this.btnStartCall.Location = new System.Drawing.Point(20, 100);
            this.btnStartCall.Name = "btnStartCall";
            this.btnStartCall.Size = new System.Drawing.Size(110, 35);
            this.btnStartCall.Text = "Start Call";
            this.btnStartCall.UseVisualStyleBackColor = true;
            this.btnStartCall.Click += new System.EventHandler(this.btnStartCall_Click);

            // btnEndCall
            this.btnEndCall.Location = new System.Drawing.Point(150, 100);
            this.btnEndCall.Name = "btnEndCall";
            this.btnEndCall.Size = new System.Drawing.Size(110, 35);
            this.btnEndCall.Text = "End Call";
            this.btnEndCall.UseVisualStyleBackColor = true;
            this.btnEndCall.Click += new System.EventHandler(this.btnEndCall_Click);

            // Form1
            this.ClientSize = new System.Drawing.Size(284, 161);
            this.Controls.Add(this.lblIP);
            this.Controls.Add(this.txtIP);
            this.Controls.Add(this.lblPort);
            this.Controls.Add(this.txtPort);
            this.Controls.Add(this.btnStartCall);
            this.Controls.Add(this.btnEndCall);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Name = "Form1";
            this.Text = "VoIP Calling App";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
