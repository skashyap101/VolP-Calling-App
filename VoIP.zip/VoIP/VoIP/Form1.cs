﻿using System;
using System.Windows.Forms;

namespace VoIPCallingApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStartCall_Click(object sender, EventArgs e)
        {
            // TODO: Implement call start logic
            MessageBox.Show("Starting call to " + txtIP.Text + ":" + txtPort.Text);
        }

        private void btnEndCall_Click(object sender, EventArgs e)
        {
            // TODO: Implement call end logic
            MessageBox.Show("Ending call");
        }
    }
}
