﻿using NAudio.Wave;
using System.Net;
using System.Net.Sockets;

public class VoiceSender
{
    private WaveInEvent waveIn;
    private UdpClient udpSender;
    private IPEndPoint remoteEndPoint;

    public VoiceSender(string ip, int port)
    {
        remoteEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);
        udpSender = new UdpClient();
    }

    public void Start()
    {
        waveIn = new WaveInEvent();
        waveIn.WaveFormat = new WaveFormat(8000, 16, 1); // 8kHz, 16-bit mono
        waveIn.DataAvailable += (s, e) =>
        {
            udpSender.Send(e.Buffer, e.BytesRecorded, remoteEndPoint);
        };
        waveIn.StartRecording();
    }

    public void Stop()
    {
        waveIn?.StopRecording();
        waveIn?.Dispose();
        udpSender?.Close();
    }
}
