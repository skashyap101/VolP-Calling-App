﻿using NAudio.Wave;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class VoiceReceiver
{
    private UdpClient udpReceiver;
    private BufferedWaveProvider bufferProvider;
    private WaveOutEvent waveOut;

    public void Start(int listenPort)
    {
        udpReceiver = new UdpClient(listenPort);
        bufferProvider = new BufferedWaveProvider(new WaveFormat(8000, 16, 1));
        waveOut = new WaveOutEvent();
        waveOut.Init(bufferProvider);
        waveOut.Play();

        Thread receiveThread = new Thread(() =>
        {
            while (true)
            {
                try
                {
                    IPEndPoint remoteEP = null;
                    byte[] data = udpReceiver.Receive(ref remoteEP);
                    bufferProvider.AddSamples(data, 0, data.Length);
                }
                catch { break; }
            }
        });
        receiveThread.IsBackground = true;
        receiveThread.Start();
    }

    public void Stop()
    {
        udpReceiver?.Close();
        waveOut?.Stop();
        waveOut?.Dispose();
    }
}
