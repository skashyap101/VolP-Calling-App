﻿using System;
using System.Windows.Forms;
using VoIPCallingApp;

namespace VoIP
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());  // ← This line expects Form1 in VoIP namespace
        }
    }
}
